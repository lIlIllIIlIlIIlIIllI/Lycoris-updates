Lycoris Stage 9 experimental CPU runtime.
API26+ ARM64 / lilac-local-ai-v3. Qwen3/hunyuan-dense Q4_K_M host-tested only.
Optional cooperative cancellation and native timing exports. CPU only; GPU/NPU unavailable.
This is a new pack ID: existing packs/models/preferences are not replaced. Select in AI settings after import.
Changing an already loaded native pack requires a process restart. Android/device inference is UNVERIFIED.
No model weights. See VERIFICATION.json and included licenses.
